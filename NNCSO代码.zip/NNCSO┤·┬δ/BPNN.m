function init_Pop = BPNN(his_POS,curr_POS)




h=size(his_POS,2);  
i=5;                   
j=size(curr_POS,2); 
Alpha=0.01;          
Beta=0.01;           %The learning rate
Gamma=0.8;          
maxIteration=20;  
trainNum=size(his_POS,1);


V=2*(rand(h,i)-0.5);  
W=2*(rand(i,j)-0.5);    
HNT=2*(rand(1,i)-0.5);  
ONT=2*(rand(1,j)-0.5);  
DeltaWOld(i,j)=0; %The amout of change for the weights  W
DeltaVOld(h,i)=0; %The amout of change for the weights  V
DeltaHNTOld(i)=0; 
DeltaONTOld(j)=0; 
Epoch=1;



[inputn,inputs] = mapminmax(his_POS');
inputn = inputn';
[outputn,outputs] = mapminmax(curr_POS');
outputn = outputn';

while Epoch<maxIteration
    for k=1:trainNum
        a=inputn(k,:);
        ck=outputn(k,:);
        % Calcluate the value of activity of hidden layer FB
        for ki=1:i
            b(ki)=tansig(a*V(:,ki)+HNT(ki));
        end;
        %  Calcluate the value of activity of hidden layer FC
        for kj=1:j
            c(kj)=tansig(b*W(:,kj)+ONT(kj));
        end;
        % Calculate the errorRate of FC
        d=(1-c.*c).*(ck-c);
        
        % Calculate the errorRate of FB
        e=(1-b.*b).*(d*W');
        
        for ki=1:i
            for kj=1:j
                DeltaW(ki,kj)=Alpha*b(ki)*d(kj)+Gamma*DeltaWOld(ki,kj);
            end
        end;
        W=W+DeltaW;
        DeltaWOld=DeltaW;
        for kh=1:h
            for ki=1:i
                DeltaV(kh,ki)=Beta*a(kh)*e(ki);                               
            end
        end;
        V=V+DeltaV;                                                    
        DeltaVold=DeltaV;                                              
        
        DeltaHNT=Beta*e+Gamma*DeltaHNTOld;
        HNT=HNT+DeltaHNT;
        DeltaHNTOld=DeltaHNT;
        DeltaONT=Alpha*d+Gamma*DeltaONTOld;
        ONT=ONT+DeltaONT;
        DeltaTauold=DeltaONT;
    end 
    Epoch = Epoch +1;
    if(d<=0.01)
        break;
    end% update the iterate number
end



inputn = outputn;

for k=1:size(inputn,1)
    a=inputn(k,:);     
    for ki=1:i
        b(ki)=logsig(a*V(:,ki)+HNT(ki));
    end;
    for kj=1:j
        c(kj)=logsig(b*W(:,kj)+ONT(kj));
    end;
    
    init_Pop(k,:)=c;

end
init_Pop = mapminmax('reverse',init_Pop',outputs);

end
